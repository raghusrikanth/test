package com.upgrad.bookingservice.dao;

import com.upgrad.bookingservice.entities.BookingInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingInfoDao extends JpaRepository<BookingInfo, Integer> {



}
