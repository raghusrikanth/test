package com.upgrad.bookingservice.controller;

import com.upgrad.bookingservice.dto.BookingInfoDto;
import com.upgrad.bookingservice.dto.PaymentDto;
import com.upgrad.bookingservice.entities.BookingInfo;
import com.upgrad.bookingservice.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookingController {

    BookingService bookingService;
    @Autowired
    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/booking/{bookingId}/transaction")
    public ResponseEntity<BookingInfo> doPayment (@RequestBody PaymentDto paymentDetails) throws Exception {
        BookingInfo bookingInfo = bookingService.doPayment(paymentDetails);
        return new ResponseEntity<BookingInfo>(bookingInfo, HttpStatus.CREATED) ;
    }

    @PostMapping("/booking")
    public ResponseEntity<BookingInfo> bookingDetails(@RequestBody BookingInfoDto bookingRequest) throws Exception {
        BookingInfo bookingInfo = this.bookingService.BookingDetails(bookingRequest);
        return new ResponseEntity<BookingInfo>(bookingInfo, HttpStatus.CREATED);
    }
}
