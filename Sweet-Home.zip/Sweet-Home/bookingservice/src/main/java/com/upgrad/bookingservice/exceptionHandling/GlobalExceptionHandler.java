package com.upgrad.bookingservice.exceptionHandling;

import com.upgrad.bookingservice.dto.CustomResponse;
import com.upgrad.bookingservice.exception.CustomException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler({CustomException.class})
    public ResponseEntity<CustomResponse> handleCustomException(Exception ex) {
        CustomResponse response = new CustomResponse(ex.getMessage(), HttpStatus.BAD_REQUEST.value());
        return new ResponseEntity<CustomResponse>(response, HttpStatus.BAD_REQUEST);
    }
}
