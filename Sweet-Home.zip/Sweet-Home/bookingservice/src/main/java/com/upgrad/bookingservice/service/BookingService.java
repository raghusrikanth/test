package com.upgrad.bookingservice.service;

import com.upgrad.bookingservice.dao.BookingInfoDao;
import com.upgrad.bookingservice.dto.BookingInfoDto;
import com.upgrad.bookingservice.dto.PaymentDto;
import com.upgrad.bookingservice.entities.BookingInfo;
import com.upgrad.bookingservice.exception.CustomException;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.Random;

@Service
public class BookingService {


    @Autowired
    BookingInfoDao bookingInfoDao;
    RestTemplate restTemplate;
    Producer<String, String > producer;
    private int priceRoomPerday = 1000;

    @Value("${url.service.payment}")
    private String paymentServiceUrl;


    @Autowired
    public BookingService(BookingInfoDao bookingInfoDao, RestTemplate restTemplate, Producer<String, String> producer){
        this.bookingInfoDao = bookingInfoDao;
        this.restTemplate = restTemplate;
        this.producer = producer;
    }

    public static ArrayList<String> getRandomNumbers(int count){
        Random rand = new Random();
        int upperBound = 100;
        ArrayList<String>numberList = new ArrayList<String>();

        for (int i=0; i<count; i++){
            numberList.add(String.valueOf(rand.nextInt(upperBound)));
        }

        return numberList;
    }

    public BookingInfo BookingDetails(BookingInfoDto bookingRequest){

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/mm/dd");
        Date date = new Date();
        int requestedNumOfRooms = bookingRequest.getNumOfRooms();

        String roomNumbers = String.join(",", getRandomNumbers(requestedNumOfRooms)) ;
        BookingInfo bookingInfo = new BookingInfo();
        bookingInfo.setRoomNumbers(roomNumbers);
        bookingInfo.setNumOfRooms(bookingRequest.getNumOfRooms());
        bookingInfo.setFromDate(bookingRequest.getFromDate());
        bookingInfo.setToDate(bookingRequest.getToDate());
        bookingInfo.setBookedOn(date);
        bookingInfo.setAadharNumber(bookingRequest.getAadharNumber());
        long numberofDays = (bookingInfo.getToDate().getTime() - bookingInfo.getFromDate().getTime())/ (1000*60*60*24) ;
        System.out.println("Number of Days: "+ numberofDays );
        bookingInfo.setRoomPrice((int) (bookingRequest.getNumOfRooms()* priceRoomPerday*numberofDays));
        System.out.println(bookingInfo.toString());
        return bookingInfoDao.save(bookingInfo);


    }

    public BookingInfo doPayment(PaymentDto paymentDetails) throws Exception {

        System.out.println(paymentDetails.toString());
        String url = this.paymentServiceUrl+"/transaction" ;

        if(!(paymentDetails.getPaymentMode().trim().equalsIgnoreCase("UPI") | paymentDetails.getPaymentMode().trim().equalsIgnoreCase("CARD"))) {
            throw new CustomException("Invalid mode of payment") ;
        }

        int bookingId = paymentDetails.getBookingId() ;
        Optional<BookingInfo> bookingInfoOptional = bookingInfoDao.findById(bookingId) ;
        if(bookingInfoOptional.isPresent()){
            BookingInfo bookingInfo = bookingInfoOptional.get() ;
            int trasactionId = restTemplate.postForObject(url, paymentDetails, Integer.class) ;
            bookingInfo.setTransactionId(trasactionId);
            bookingInfoDao.save(bookingInfo);
            String message = "Booking confirmed for user with aadhar number " + bookingInfo.getAadharNumber() + " | " + "Here are the booking details:"
                    + bookingInfo.toString();
            producer.send(new ProducerRecord<String, String>("messages", "messages", message)) ;
            return bookingInfo;
        }
        else {
            throw new CustomException("Invalid booking Id") ;
        }



    }
}
