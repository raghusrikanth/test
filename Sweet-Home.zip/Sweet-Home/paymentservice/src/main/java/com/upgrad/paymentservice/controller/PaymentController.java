package com.upgrad.paymentservice.controller;

import com.upgrad.paymentservice.entity.PaymentDetailEntity;
import com.upgrad.paymentservice.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class PaymentController {

    PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService){
        super();
        this.paymentService = paymentService ;
    }

    @PostMapping("/transaction")
    public ResponseEntity<Integer> makePayment(@RequestBody PaymentDetailEntity paymentDetails) {
        int paymentId = this.paymentService.makePayment(paymentDetails) ;

        return new ResponseEntity<Integer>(paymentId, HttpStatus.CREATED) ;
    }

    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<PaymentDetailEntity> getPaymentById(@PathVariable int transactionId) throws Exception {
        PaymentDetailEntity paymentDetails = this.paymentService.getPaymentById(transactionId) ;

        return new ResponseEntity<PaymentDetailEntity>(paymentDetails, HttpStatus.OK) ;
    }

}
