package com.upgrad.paymentservice.dao;

import com.upgrad.paymentservice.entity.PaymentDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentDetailsDao extends JpaRepository<PaymentDetailEntity, Integer> {
}
