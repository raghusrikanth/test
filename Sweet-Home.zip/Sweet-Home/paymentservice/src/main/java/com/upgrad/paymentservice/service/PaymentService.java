package com.upgrad.paymentservice.service;

import com.upgrad.paymentservice.dao.PaymentDetailsDao;
import com.upgrad.paymentservice.entity.PaymentDetailEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PaymentService {

    PaymentDetailsDao paymentDetailsDao;

    @Autowired
    public PaymentService(PaymentDetailsDao paymentDetailsDao){
        super();
        this.paymentDetailsDao = paymentDetailsDao ;
    }

    public  int makePayment(PaymentDetailEntity paymentRequest){
        return this.paymentDetailsDao.save(paymentRequest).getId() ;
    }

    public PaymentDetailEntity getPaymentById(int paymenId) throws Exception{
        Optional<PaymentDetailEntity> paymentDetailDaoOp = this.paymentDetailsDao.findById(paymenId) ;

        if(paymentDetailDaoOp.isPresent()){
            return paymentDetailDaoOp.get();
        }else{
            throw new Exception("Payment Id Not Found");
        }
    }
}
